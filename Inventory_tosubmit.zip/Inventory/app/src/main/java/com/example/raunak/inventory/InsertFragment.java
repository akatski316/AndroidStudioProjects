package com.example.raunak.inventory;

import android.content.ContentValues;
import android.content.UriMatcher;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.NavUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.example.raunak.inventory.data.ProductContract;


public class InsertFragment extends Fragment {
    private EditText mNameEditText;
    private EditText mprice;
    private EditText mquantity;
    private EditText mSupplierContact;
    private EditText msupplier;
    View v;
    FloatingActionButton fb;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_insert, container, false);

        mNameEditText = (EditText) v.findViewById(R.id.edit_product_name);
        mprice = (EditText) v.findViewById(R.id.edit_product_price);
        mquantity = (EditText) v.findViewById(R.id.quantity);
        mSupplierContact = (EditText) v.findViewById(R.id.supplier_contact);
        msupplier = (EditText) v.findViewById(R.id.supplier);

        fb = v.findViewById(R.id.fab);
        fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertProduct();
            }
        });
        return v;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_editor, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // User clicked on a menu option in the app bar overflow menu
        switch (item.getItemId()) {
            // Respond to a click on the "Save" menu option
            case R.id.action_save:
                //Save Product to database
                Log.d("tick","inserting product");
                insertProduct();
                // Exit Fragment
                return true;
            //Respond to a click on the "Deleteenu option
            case R.id.action_delete:
                // Do nothing for now
                return true;
            // Respond to a click on the "Up" arrow button in the app bar
            case android.R.id.home:
                // Navigate back to parent activity (CatalogActivity)
                NavUtils.navigateUpFromSameTask(getActivity());
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void insertProduct() {
        // Create a ContentValues object where column names are the keys,
        // and Toto's pet attributes are the values.
        String name = mNameEditText.getText().toString().trim();
        String supplier_name = msupplier.getText().toString().trim();
        try {
            Integer price = Integer.parseInt(mprice.getText().toString().trim());
            Integer quantity = Integer.parseInt(mquantity.getText().toString().trim());
            Integer contact = Integer.parseInt(mSupplierContact.getText().toString().trim());
            ContentValues values = new ContentValues();
            values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_NAME,name);
            values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_PRICE,price);
            values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_QUANTITY,quantity);
            values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER,supplier_name);
            values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER_CONTACT,contact);
            Uri newUri = getContext().getContentResolver().insert(ProductContract.ProductEntry.databaseUri, values);

            UriMatcher sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
            Toast.makeText(getContext(),"added to the list and id is "+sUriMatcher.match(newUri),Toast.LENGTH_SHORT).show();
        }
        catch(Exception e)
        {
            Toast.makeText(getContext(),"nothing has been added to list input correct info",Toast.LENGTH_SHORT).show();
            Log.d("insertproduct",e.toString());
        }
    }
}
