package com.example.raunak.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.raunak.inventory.data.ProductContract;

import java.util.ArrayList;
import java.util.List;

public class MyProductRecyclerViewAdapter extends RecyclerView.Adapter<MyProductRecyclerViewAdapter.MyProductViewHolder>
{

    Context mCtx;
    List<Product> productList;

    public MyProductRecyclerViewAdapter(Context mCtx, List<Product> productList) {
        this.mCtx = mCtx;
        this.productList = productList;
    }

    @Override
    public MyProductRecyclerViewAdapter.MyProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        //..converting product_layout into view object
        View view = LayoutInflater.from(mCtx).inflate(R.layout.catalog_list_item, parent, false);

        //..extracting data from view and construct a ProductViewHolder object
        MyProductRecyclerViewAdapter.MyProductViewHolder productViewHolder = new MyProductRecyclerViewAdapter.MyProductViewHolder(view);
        return productViewHolder;
    }

    @Override
    public void onBindViewHolder(final MyProductRecyclerViewAdapter.MyProductViewHolder holder, final int position) {
        Product product = productList.get(position);

        holder.name_view.setText(product.getName());
        holder.price.setText(product.getPrice());
        holder.quantity.setText(product.getQuantity());

        holder.btn_dec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String new_quantity = productList.get(position).getQuantity();
                new_quantity = new_quantity.substring(10,new_quantity.length());
                new_quantity = ""+(Integer.parseInt(new_quantity) - 1);

                Log.d("dec","new quantity is "+new_quantity);

                if (Integer.parseInt(new_quantity) != -1)
                {
                    ContentValues values = new ContentValues();
                    values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_NAME, (productList.get(position).getName()).substring(6));
                    values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_PRICE, (productList.get(position).getPrice()).substring(7));
                    values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_QUANTITY, new_quantity);
                    values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER, (productList.get(position).getSupplier()).substring(14));
                    values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER_CONTACT, (productList.get(position).getSupplier_contact()).substring(20));
                    int rowupdated = mCtx.getContentResolver().update(Uri.parse(ProductContract.ProductEntry.databaseUri + "/" + productList.get(position).getId()), values, null, null);
                    productList = getAll_data();
                    holder.quantity.setText("Quantity: "+new_quantity);
                }
                else
                    Toast.makeText(mCtx,"product is already out of stock ",Toast.LENGTH_LONG).show();
            }
        });

        holder.btn_inc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String new_quantity = productList.get(position).getQuantity();
                new_quantity = new_quantity.substring(10,new_quantity.length());
                new_quantity = ""+(Integer.parseInt(new_quantity) + 1);

                Log.d("inc","new quantity is "+new_quantity);

                ContentValues values = new ContentValues();
                values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_NAME, (productList.get(position).getName()).substring(6));
                values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_PRICE, (productList.get(position).getPrice()).substring(7));
                values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_QUANTITY, new_quantity);
                values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER, (productList.get(position).getSupplier()).substring(14));
                values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER_CONTACT, (productList.get(position).getSupplier_contact()).substring(20));
                mCtx.getContentResolver().update(Uri.parse(ProductContract.ProductEntry.databaseUri + "/" + productList.get(position).getId()), values, null, null);
                productList = getAll_data();
                holder.quantity.setText("Quantity: "+new_quantity);
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ProductDetails obj = new ProductDetails(mCtx, productList.get(position).getId(), productList.get(position).getName(), productList.get(position).getPrice(), productList.get(position).getSupplier(), productList.get(position).getSupplier_contact(), productList.get(position).getQuantity());
                obj.show();
            }
        });

    }

    @Override
    public int getItemCount() {
        try {
            return productList.size();

        } catch (Exception e) {
            return 0;

        }
    }

    public ArrayList<Product> getAll_data()
    {
        ArrayList<Product> toReturn = new ArrayList<>();
        Log.d("getAllData","getting all readable database");
        String[] projections = {ProductContract.ProductEntry._ID, ProductContract.ProductEntry.COLUMN_PRODUCT_NAME, ProductContract.ProductEntry.COLUMN_PRODUCT_PRICE, ProductContract.ProductEntry.COLUMN_PRODUCT_QUANTITY, ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER, ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER_CONTACT};
        Cursor c;

        try{
            c = mCtx.getContentResolver().query(ProductContract.ProductEntry.databaseUri,projections,null,null,null,null);
        }
        catch (Exception e)
        {
            Log.d("getAll","returning toReturn list");
            return toReturn;
        }

        Log.d("getAlldata","cursor is at "+c.getPosition());
        while(c.moveToNext())
        {
            String[] temp = new String[6];
            for(int i = 0; i < projections.length;i++)
            {
                temp[i] = c.getString(i);
                Log.d("getAllData","temp is "+temp);
            }
            toReturn.add(new Product("Id: "+temp[0],"Name: "+temp[1],"Price: "+temp[2],"Quantity: "+temp[3],"Supplier Name: "+temp[4],"Supplier Contact No: "+temp[5]));
        }
        c.close();
        Log.d("HomeFragement getall","returning list");
        return toReturn;
    }

    /**just a view holder class*/
    public  class MyProductViewHolder extends RecyclerView.ViewHolder
    {
        TextView name_view, price, quantity;
        Button btn_dec,btn_inc;
        public MyProductViewHolder(View item) {
            super(item);
            name_view = item.findViewById(R.id.name);
            price = item.findViewById(R.id.price);
            quantity = item.findViewById(R.id.quantity);
            btn_dec=item.findViewById(R.id.btn_dec);
            btn_inc = item.findViewById(R.id.btn_inc);
        }
    }
}
