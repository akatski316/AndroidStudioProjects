package com.example.raunak.inventory;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class MyProductRecyclerViewAdapterDelete extends RecyclerView.Adapter<MyProductRecyclerViewAdapterDelete.MyProductViewHolder>
{

    Context mCtx;
    List<Product> productList;

    public MyProductRecyclerViewAdapterDelete(Context mCtx, List<Product> productList) {
        this.mCtx = mCtx;
        this.productList = productList;
    }

    @Override
    public MyProductRecyclerViewAdapterDelete.MyProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        //..converting product_layout into view object
        View view = LayoutInflater.from(mCtx).inflate(R.layout.delete_list_item, parent, false);

        //..extracting data from view and construct a ProductViewHolder object
        MyProductRecyclerViewAdapterDelete.MyProductViewHolder productViewHolder = new MyProductRecyclerViewAdapterDelete.MyProductViewHolder(view);
        return productViewHolder;
    }

    @Override
    public void onBindViewHolder(MyProductRecyclerViewAdapterDelete.MyProductViewHolder holder, final int position) {
        Product product = productList.get(position);
        holder.name_view.setText(product.getName());
        holder.price.setText(product.getPrice());
        holder.quantity.setText(product.getQuantity());
    }

    @Override
    public int getItemCount() {
        try {
            return productList.size();

        } catch (Exception e) {
            return 0;

        }
    }

    /**just a view holder class*/
    public  class MyProductViewHolder extends RecyclerView.ViewHolder
    {
        TextView name_view, price, quantity;
        Button btn;
        public MyProductViewHolder(View item) {
            super(item);
            name_view = item.findViewById(R.id.name);
            price = item.findViewById(R.id.price);
            quantity = item.findViewById(R.id.quantity);
            btn=item.findViewById(R.id.btn_dec);
        }
    }
}
