package com.example.raunak.inventory;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.raunak.inventory.data.ProductContract;

public class Update_Editor extends AppCompatActivity {

    private EditText mNameEditText;

    private EditText mprice;

    private EditText mquantity;

    private EditText mSupplierContact;

    private EditText msupplier;

    private String id;

    FloatingActionButton fb;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update__editor);
        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        mNameEditText = (EditText) findViewById(R.id.edit_product_name);
        mNameEditText.setText(intent.getStringExtra("name"));

        mprice = (EditText) findViewById(R.id.edit_product_price);
        mprice.setText(intent.getStringExtra("price"));

        mquantity = (EditText) findViewById(R.id.quantity);
        mquantity.setText(intent.getStringExtra("quantity"));

        mSupplierContact = (EditText) findViewById(R.id.supplier_contact);
        mSupplierContact.setText(intent.getStringExtra("supplier_contact"));

        msupplier = (EditText) findViewById(R.id.supplier);
        msupplier.setText(intent.getStringExtra("supplier"));

        fb = findViewById(R.id.fab);
        fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Update_Editor.this);
                builder.setTitle("Update Product");
                builder.setMessage("Do you want to update current product?");
                builder.setCancelable(false);

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        updateProduct();
                        dialog.dismiss();
                        finish();

                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }


    private void updateProduct() {
        // Create a ContentValues object where column names are the keys,
        // and Toto's pet attributes are the values.
        String name = mNameEditText.getText().toString().trim();
        String supplier_name = msupplier.getText().toString().trim();

        try {
            Integer price = Integer.parseInt(mprice.getText().toString().trim());
            Integer quantity = Integer.parseInt(mquantity.getText().toString().trim());
            Integer contact = Integer.parseInt(mSupplierContact.getText().toString().trim());
            ContentValues values = new ContentValues();
            values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_NAME,name);
            values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_PRICE,price);
            values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_QUANTITY,quantity);
            values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER,supplier_name);
            values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER_CONTACT,contact);

            this.getContentResolver().update(Uri.parse(ProductContract.ProductEntry.databaseUri+"/"+id),values,null,null);
        }
        catch(Exception e)
        {
            Toast.makeText(this,"nothing has been updated to list",Toast.LENGTH_SHORT).show();
            Log.d("insertproduct",e.toString());
        }
    }
}
