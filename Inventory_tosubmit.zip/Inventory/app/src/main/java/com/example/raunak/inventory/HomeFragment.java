package com.example.raunak.inventory;

import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.raunak.inventory.data.ProductContract;
import com.example.raunak.inventory.data.ProductDbHelper;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    RecyclerView recyclerView;
    MyProductRecyclerViewAdapter adapter;
    List<Product> productList;
    public static ProductDbHelper helper;
    public View v;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_home, container, false);
        helper = new ProductDbHelper(getContext());
        recyclerView = v.findViewById(R.id.list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        Log.d("tag",ProductDbHelper.SQL_CREATE_PRODUCTS_TABLE);
        try {
            productList = getAll_data();
            Log.d("oncreateViewHomeFrag","product list initiated "+productList.size());
            if(productList.size() == 0 || productList == null)
            {
                v.findViewById(R.id.list).setVisibility(View.GONE);
                v.findViewById(R.id.emptyview_text).setVisibility(View.VISIBLE);
                return v;
            }
        }
        catch(Exception e)
        {
            Toast.makeText(getContext(),"no database yet",Toast.LENGTH_SHORT).show();
        }
        adapter = new MyProductRecyclerViewAdapter(getContext(),productList);
        recyclerView.setAdapter(adapter);
        Log.d("oncreateViewHomeFrag","onCreateView is finished");
        return v;
    }

    public ArrayList<Product> getAll_data()
    {
        ArrayList<Product> toReturn = new ArrayList<>();
        Log.d("getAllData","getting all readable database");
        String[] projections = {ProductContract.ProductEntry._ID, ProductContract.ProductEntry.COLUMN_PRODUCT_NAME, ProductContract.ProductEntry.COLUMN_PRODUCT_PRICE, ProductContract.ProductEntry.COLUMN_PRODUCT_QUANTITY, ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER, ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER_CONTACT};
        Cursor c;
        try{
            c = getContext().getContentResolver().query(ProductContract.ProductEntry.databaseUri,projections,null,null,null,null);
        }
        catch (Exception e)
        {
            Log.d("getAll","returning toReturn list");
            return toReturn;
        }
        Log.d("getAlldata","cursor is at "+c.getPosition());
        while(c.moveToNext())
        {
            String[] temp = new String[6];
            for(int i = 0; i < projections.length;i++)
            {
                temp[i] = c.getString(i);
                Log.d("getAllData","temp is "+temp);
            }
            toReturn.add(new Product("Id: "+temp[0],"Name: "+temp[1],"Price: "+temp[2],"Quantity: "+temp[3],"Supplier Name: "+temp[4],"Supplier Contact No: "+temp[5]));
        }
        c.close();
        Log.d("HomeFragement getall","returning list");
        return toReturn;
    }

    @Override
    public void onResume()
    {
        super.onResume();
        Log.d("onResumeHomeFrag","inside onResume");
        productList = getAll_data();
        if(productList.size() == 0 || productList == null)
        {
            v.findViewById(R.id.list).setVisibility(View.GONE);
            v.findViewById(R.id.emptyview_text).setVisibility(View.VISIBLE);
            return;
        }
        v.findViewById(R.id.list).setVisibility(View.VISIBLE);
        adapter = new MyProductRecyclerViewAdapter(getContext(),productList);
        recyclerView.setAdapter(adapter);
    }
}
