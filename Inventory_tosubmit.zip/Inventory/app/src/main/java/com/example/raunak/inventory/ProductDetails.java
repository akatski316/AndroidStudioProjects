package com.example.raunak.inventory;


import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.KeyboardShortcutGroup;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import com.example.raunak.inventory.data.ProductContract;

import java.util.List;

public class ProductDetails extends Dialog {


    public String name,id, price, supplier,supplier_contact,quantity;

    public ProductDetails(@NonNull Context context, String id, String name, String price, String supplier, String supplier_contact, String quantity) {
        super(context);
        this.id = id;
        this.name = name;
        this.price = price;
        this.supplier = supplier;
        this.supplier_contact = supplier_contact;
        this.quantity = quantity;
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        setContentView(R.layout.product_details);

        TextView name_view = (TextView)findViewById(R.id.info_name);
        name_view.setText(name);
        TextView price_view = (TextView)findViewById(R.id.info_price);
        price_view.setText(price);
        TextView suplier_view = (TextView)findViewById(R.id.info_supplier);
        suplier_view.setText(supplier);
        TextView supplier_contact_view = (TextView)findViewById(R.id.info_supplier_contact);
        supplier_contact_view.setText(supplier_contact);
        final TextView quantity_view = (TextView)findViewById(R.id.info_quantity);
        quantity_view.setText(quantity);

        Button call = findViewById(R.id.order);
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String call = supplier_contact.substring(20);
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:"+call));
                callIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                Log.d("ProductDetl","calling...");
                getContext().startActivity(callIntent);
            }
        });

        ImageButton delete = findViewById(R.id.detail_delete);

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle("Delete Product");
                builder.setMessage("Do you want to Delete?");
                builder.setCancelable(true);

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.dismiss();
                    }
                });

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int i) {
                        Log.d("product","id sent is "+id);
                        int rowdeleted = getContext().getContentResolver().delete(Uri.parse(ProductContract.ProductEntry.databaseUri+"/"+id), null,null);
                        Log.d("product","deleted at "+rowdeleted);
                        dialog.dismiss();
                        dismiss();
                        Toast.makeText(getContext(),"refresh the screen to see updates",Toast.LENGTH_LONG).show();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        Button add = findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String new_quantity = quantity;
                new_quantity = new_quantity.substring(10,new_quantity.length());
                new_quantity = ""+(Integer.parseInt(new_quantity) + 1);

                Log.d("inc","new quantity is "+new_quantity);

                ContentValues values = new ContentValues();
                values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_NAME, name.substring(6));
                values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_PRICE, price.substring(7));
                values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_QUANTITY, new_quantity);
                values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER, supplier.substring(14));
                values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER_CONTACT, supplier_contact.substring(20));
                getContext().getContentResolver().update(Uri.parse(ProductContract.ProductEntry.databaseUri + "/" + id), values, null, null);
                Log.d("ProdcutDetails","setting quantity to "+new_quantity);
                quantity_view.setText("Quantity:" +new_quantity);
                quantity = "Quantity: "+new_quantity;
            }

        });

        Button sub = findViewById(R.id.substract);
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String new_quantity = quantity;
                new_quantity = new_quantity.substring(10,new_quantity.length());
                new_quantity = ""+(Integer.parseInt(new_quantity) - 1);

                Log.d("inc","new quantity is "+Integer.parseInt(new_quantity));
                if(Integer.parseInt(new_quantity) != -1)
                {
                    ContentValues values = new ContentValues();
                    values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_NAME, name.substring(6));
                    values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_PRICE, price.substring(7));
                    values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_QUANTITY, new_quantity);
                    values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER, supplier.substring(14));
                    values.put(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER_CONTACT, supplier_contact.substring(20));
                    getContext().getContentResolver().update(Uri.parse(ProductContract.ProductEntry.databaseUri + "/" + id), values, null, null);
                    quantity_view.setText("Quantity:" +new_quantity);
                    quantity = "Quantity: "+new_quantity;
                }
                else
                    Toast.makeText(getContext(),"product is already out of stock ",Toast.LENGTH_LONG).show();
            }

        });
    }


    @Override
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> data, @Nullable Menu menu, int deviceId) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
