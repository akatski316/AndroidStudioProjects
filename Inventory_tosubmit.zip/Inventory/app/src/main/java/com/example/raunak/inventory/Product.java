package com.example.raunak.inventory;

public class Product
{
    String name, price, quantity, supplier,id,supplier_contact;

    public Product(String id,String name, String price, String quantity, String supplier,  String supplier_contact) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.supplier = supplier;
        this.id = id;
        this.supplier_contact = supplier_contact;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setSupplier_contact(String supplier_contact) {
        this.supplier_contact = supplier_contact;
    }

    public String getSupplier_contact() {
        return supplier_contact;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }

    public String getId() {
        return id;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getSupplier() {
        return supplier;
    }
}