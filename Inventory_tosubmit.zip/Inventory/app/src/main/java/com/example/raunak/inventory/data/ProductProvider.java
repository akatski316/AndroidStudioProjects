package com.example.raunak.inventory.data;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;


public class ProductProvider extends ContentProvider {

    public ProductDbHelper helper;
    public static final  int PRODUCT =100;
    public static final int PRODUCT_id = 101;
    /**
     * Initialize the provider and the database helper object.
     */
    private static final UriMatcher sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        sUriMatcher.addURI("com.example.raunak.inventory","Product",PRODUCT);
        sUriMatcher.addURI("com.example.raunak.inventory","Product/#",PRODUCT_id);
    }
    @Override
    public boolean onCreate() {
        // TODO: Create and initialize a ProductDbHelper object to gain access to the products database.
        // Make sure the variable is a global variable, so it can be referenced from other
        // ContentProvider methods.
        helper = new ProductDbHelper(getContext());
        return true;
    }

    /**
     * Perform the query for the given URI. Use the given projection, selection, selection arguments, and sort order.
     */
    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {
        // Get readable database
        SQLiteDatabase database = helper.getReadableDatabase();
        Log.d("queryprovider","SQLitedatabase instantiated");
        // This cursor will hold the result of the query
        Cursor cursor;

        // Figure out if the URI matcher can match the URI to a specific code
        int match = sUriMatcher.match(uri);
        Log.d("queryprovider","matching the uri and its of type "+match);
        switch (match) {
            case PRODUCT:
                cursor = database.query(ProductContract.ProductEntry.TABLE_NAME, projection, null, null,
                        null, null, sortOrder);
                Log.d("queryprovider","its of type 1  and cursor is "+cursor.getPosition());
                break;
            case PRODUCT_id:
                selection = ProductContract.ProductEntry._ID + "=?";
                selectionArgs = new String[] { String.valueOf(ContentUris.parseId(uri)) };

                cursor = database.query(ProductContract.ProductEntry.TABLE_NAME, projection, selection, selectionArgs,
                        null, null, sortOrder);

                Log.d("queryprovider","its of type 2  and cursor is "+cursor.getPosition());
                break;
            default:
                throw new IllegalArgumentException("Cannot query unknown URI " + uri);
        }
        Log.d("queryprovider","returning cursor");
        return cursor;
    }


    /**
     * Insert new data into the provider with the given ContentValues.
     */

    @Override
    public Uri insert(Uri uri, ContentValues values) {

        int match = sUriMatcher.match(uri);

        switch (match) {
            case PRODUCT:
                return insertProduct(uri,values);
            default:
                Toast.makeText(getContext(), "Error with saving pet", Toast.LENGTH_SHORT).show();
        }

        return null;
    }

    private Uri insertProduct(Uri uri, ContentValues values) {

        if(Valid(values))
        {
            SQLiteDatabase db = helper.getWritableDatabase();
            long newRowId = db.insert(ProductContract.ProductEntry.TABLE_NAME, null, values);
            Log.d("insertProduct","newRowId is "+newRowId);
            // Show a toast message depending on whether or not the insertion was successful
            if (newRowId == -1) {
                // If the row ID is -1, then there was an error with insertion.
                Toast.makeText(getContext(), "Error with saving product", Toast.LENGTH_SHORT).show();
            } else {
                // Otherwise, the insertion was successful and we can display a toast with the row ID.
                Toast.makeText(getContext(), "Product saved with row id: " + newRowId, Toast.LENGTH_SHORT).show();
            }
            Log.d("insertProduct","current uri is "+uri.toString());
            return ContentUris.withAppendedId(uri, newRowId);
        }
        else if(!Valid(values))
            Toast.makeText(getContext(), "some field(s) are not filled or ar not valid" , Toast.LENGTH_SHORT).show();
        return null;
    }

    public boolean Valid(ContentValues values)
    {
        if(!ValidName(values.getAsString(ProductContract.ProductEntry.COLUMN_PRODUCT_NAME))) {
            Log.d("Valid","name is not valid");
            return false;
        }
        if(!ValidPrice(values.getAsInteger(ProductContract.ProductEntry.COLUMN_PRODUCT_PRICE))) {
            Log.d("Valid","price is not valid");
            return false;
        }
        if(!ValidQuantity(values.getAsInteger(ProductContract.ProductEntry.COLUMN_PRODUCT_QUANTITY))) {
            Log.d("Valid","quantity is not valid");
            return false;
        }
        if(!ValidSupplier(values.getAsString(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER))) {
            Log.d("Valid","supplier is not valid");
            return false;
        }
        if(!ValidContact(values.getAsInteger(ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER_CONTACT))) {
            Log.d("Valid","supplier contact is not valid");
            return false;
        }
        return true;
    }

    public boolean ValidName(String name)
    {
        if(name == null)
            return  false;
        return true;
    }

    public boolean ValidPrice(Integer price)
    {
        if(price == null)
            return false;
        return true;
    }

    public boolean ValidQuantity(Integer quantity)
    {
        if(quantity == null)
            return false;
        return  true;
    }

    public boolean ValidSupplier(String supplier)
    {
        if(supplier == null)
            return false;
        return  true;
    }

    public boolean ValidContact(Integer contact)
    {
        if(contact == null)
            return false;
        return true;
    }

    /**
     * Updates the data at the given selection and selection arguments, with the new ContentValues.
     */
    @Override
    public int update(Uri uri, ContentValues contentValues, String selection, String[] selectionArgs) {
        Log.d("updateprovider","trying to update");

        selection = ProductContract.ProductEntry._ID + "=?";
        Log.d("updateprovider","selectio is "+selection);
        return updateProduct(uri, contentValues, selection, selectionArgs);

    }

    public int updateProduct(Uri uri, ContentValues contentValues, String selection, String[] selectionArgs)
    {
        Log.d("updateproduct","inside updateProduct");
        SQLiteDatabase db = helper.getWritableDatabase();
        Log.d("updateproduct","db is instantiated");
        String uri_str = uri.toString();
        Log.d("updateproduct","heres the uri "+uri_str);
        Integer id;
        try {
            id = Integer.parseInt(uri_str.substring(51));
        }
        catch(Exception e)
        {
            id = Integer.parseInt(uri_str.substring(47));
        }
        Log.d("updateproduct","heres the id number"+id);
        return db.update(ProductContract.ProductEntry.TABLE_NAME,contentValues,ProductContract.ProductEntry._ID+" = "+id,null);
    }
    /**
     * Delete the data at the given selection and selection arguments.
     */
    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        SQLiteDatabase db = helper.getWritableDatabase();
        String uri_str = uri.toString();
        Log.d("deleteProvider","uri is "+uri_str);
        Integer id = Integer.parseInt(uri_str.substring(51));
        Log.d("deleteprovider",uri.toString());
        int deleterow = db.delete(ProductContract.ProductEntry.TABLE_NAME,ProductContract.ProductEntry._ID+" = "+id,null);
        Log.d("deleteprovider","deleted row "+deleterow);
        return deleterow;
    }

    /**
     * Returns the MIME type f data for the content URI.
     */
    @Override
    public String getType(Uri uri) {
        return null;
    }
}