package com.example.raunak.inventory;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.raunak.inventory.data.ProductContract;
import com.example.raunak.inventory.data.ProductDbHelper;

import java.util.ArrayList;
import java.util.List;


public class UpdateFragment extends Fragment {
    RecyclerView recyclerView;
    MyProductRecyclerViewAdapterUpdate adapter;
    List<Product> productList;
    public static ProductDbHelper helper;
    public View v;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.fragment_update, container, false);
        helper = new ProductDbHelper(getContext());

        recyclerView = v.findViewById(R.id.list_update);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        Log.d("tag",ProductDbHelper.SQL_CREATE_PRODUCTS_TABLE);

        try {
            productList = getAll_data();
            for(Product i : productList)
            {
                i.setId("ID: "+i.getId());
                i.setName("NAME: "+i.getName());
                i.setId("PRICE: "+i.getPrice());
                i.setId("SUPPLIER: "+i.getSupplier());
                i.setId("SUPPLIERCONTACT: "+i.getSupplier_contact());
                i.setId("QUANTITY: "+i.getQuantity());
            }
            if(productList.size() == 0 || productList == null)
            {
                v.findViewById(R.id.list).setVisibility(View.GONE);
                v.findViewById(R.id.emptyview_text).setVisibility(View.VISIBLE);
                return v;
            }
            Log.d("oncreateViewHomeFrag","product list initiated "+productList.size());
        }
        catch(Exception e)
        {
            Toast.makeText(getContext(),"no database yet",Toast.LENGTH_SHORT).show();
        }
        adapter = new MyProductRecyclerViewAdapterUpdate(getContext(),productList);
        recyclerView.setAdapter(adapter);
        Log.d("oncreateViewHomeFrag","onCreateView is finished");

        recyclerView.addOnItemTouchListener(
                new RecyclerViewClickListener(getContext(), recyclerView, new RecyclerViewClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        productList = getAll_data();
                        Intent update_activity = new Intent(getContext(),Update_Editor.class);
                        update_activity.putExtra("id",productList.get(position).getId());
                        update_activity.putExtra("name",productList.get(position).getName());
                        update_activity.putExtra("price",productList.get(position).getPrice());
                        update_activity.putExtra("supplier",productList.get(position).getSupplier());
                        update_activity.putExtra("supplier_contact",productList.get(position).getSupplier_contact());
                        update_activity.putExtra("quantity",productList.get(position).getQuantity());

                        startActivity(update_activity);
                    }

                    @Override
                    public void onLongItemClick(View view, int position) { }
                })
        );
        return v;
    }

    public ArrayList<Product> getAll_data()
    {
        ArrayList<Product> toReturn = new ArrayList<>();
        Log.d("getAllData","getting all readable database");
        String[] projections = {ProductContract.ProductEntry._ID, ProductContract.ProductEntry.COLUMN_PRODUCT_NAME, ProductContract.ProductEntry.COLUMN_PRODUCT_PRICE, ProductContract.ProductEntry.COLUMN_PRODUCT_QUANTITY, ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER, ProductContract.ProductEntry.COLUMN_PRODUCT_SUPPLIER_CONTACT};
        Cursor c;

        try{
            c = getContext().getContentResolver().query(ProductContract.ProductEntry.databaseUri,projections,null,null,null,null);
        }
        catch (Exception e)
        {
            Log.d("getAll","returning toReturn list");
            return toReturn;
        }

        Log.d("getAlldata","cursor is at "+c.getPosition());
        while(c.moveToNext())
        {
            String[] temp = new String[6];
            for(int i = 0; i < projections.length;i++)
            {
                temp[i] = c.getString(i);
                Log.d("getAllData","temp is "+temp);
            }
            toReturn.add(new Product(temp[0],temp[1],temp[2],temp[3],temp[4],temp[5]));
        }
        c.close();
        Log.d("HomeFragement getall","returning list");
        return toReturn;
    }



    @Override
    public void onResume() {
        super.onResume();
        Log.d("onResumeHomeFrag","inside onResume");
        productList = getAll_data();
        if(productList.size() == 0 || productList == null)
        {
            v.findViewById(R.id.list_update).setVisibility(View.GONE);
            v.findViewById(R.id.emptyview_text).setVisibility(View.VISIBLE);
        }
        adapter = new MyProductRecyclerViewAdapterUpdate(getContext(),productList);
        recyclerView.setAdapter(adapter);
    }

}
